#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc,char *argv[])
{
  //int x = 0;
  cps();

 // printf("TOTAL = %d",x);

  exit();
}
