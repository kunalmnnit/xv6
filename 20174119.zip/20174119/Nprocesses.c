#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    int i;
    if( argc >= 2 )
    {
    pid_t pid;
    int ret;

	int n=0;//,l=strlen(argv[1]);
	//char c=(argv[1][0]);
	n = atoi(argv[1]);
	pid = fork();
	for(int i=0;i<n-1;i++)
	{
	switch(pid)
	    {
		case -1: printf("error!\n");exit(1);
		break;
		case 0:
		//printf("THIS is CHILD process! pid : %d\tparent pid : %d\n",getpid(),getppid());
		break;
		default:
		printf("THIS is Parent process! pid : %d\tChild pid : %d\tOwner id : %d\n",getpid(),pid,getppid());
		pid = fork();
		wait(0);
		break;
	    }
	}	
	//if(pid == 0) sleep(5);
	}
    else
    {
        printf("argument list is empty.\n");
    }

    return 0;
}

















