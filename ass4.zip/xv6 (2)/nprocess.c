#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{ 
  if(argc < 2){ 
    printf(1," smaller number of arguments than specified , error !\n ");
    exit();
  }

  if(argc > 2){
    printf(1," greater number of arguments than specified , error !\n ");
    exit();
  }

  int i=0;
  int num=atoi(argv[1]);

  

  int pp;
  //int count = 1 ;
 // printf(1,"ChildProcess 1\n");
  for(i=1;i<num;i++){
     if((pp = fork())== 0 ){
	printf(1,"ChildProcess %d\n",0);
     }
     else
	{
          break ;
	}
      
  }

  if(pp != 0){
     wait();
     exit();
 }

  sleep(1000);
  exit();
}
