#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"
#include "fcntl.h"


int main(int argc,char* argv[]){

	struct pro p;
	int pid=atoi(argv[1]);
	getprocinfo(pid,&p);
	printf(1,"%d\t%s\n",p.pid,p.name);
	exit();
}
