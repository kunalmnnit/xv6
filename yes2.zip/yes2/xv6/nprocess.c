#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
  	int  k, n, p;
 	double x = 0,  z;

	n = atoi ( argv[1] ); //from command line
	
	for(k=0; k<n; k++)
	{
		p=fork();
		if(p>0)
			printf(1,"parent creating child %d\n", k);

		else
		{
			printf(1,"child %d created\n", k);
			for(z=0; z<300000000; z=z+0.1)		
				x+= 34.56*45.78;
		
			break;		
		}
	}

return 0;
}
