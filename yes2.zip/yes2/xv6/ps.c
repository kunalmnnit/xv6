#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "stat.h"

int 
main(int argc, char* argv[])
{
	int x;
	if(argc==1)
		x= cps(1);

	else
		x= cps(2);
	
	int a= x/10000;
	int b= x%10000;
	printf(1,"running process=%d sleeping process=%d\n",a,b);
	return 0;
}
