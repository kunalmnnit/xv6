#include "types.h"
#include "user.h"
#include "fcntl.h"
#include "stat.h"

int 
main(int argc, char* argv[])
{
	char s[3000];
	int fd,fd1;
	fd= open(argv[1], O_RDWR);
	fd1= open(argv[2], O_CREATE | O_RDWR);
	
	int siz= read(fd, s, 3000);
	write(fd1, s, siz);

	close(fd);
	close(fd1);
	return 0;
}
