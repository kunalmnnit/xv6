#include "types.h"
#include "stat.h"
#include "fcntl.h"
#include "user.h"

int main(int argc, char* argv[])
{
	int x= getpid();
	int n= numproc(x);
	int a= n/10000;
	int b= n%10000;

	
	printf(1,"active process in system are= %d\n", a);
	printf(1,"process with max pid= %d\n", b);
return 0;
}
