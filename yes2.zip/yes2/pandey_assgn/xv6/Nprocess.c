/*#include "types.h"
#include "fs.h"
#include "user.h"
#include "stat.h"

int getNum(char ch[])
{
	int i=0,l=0,N=0;
	while(ch[i++]!='\0')
	{
		l++;
	}
	for(i=0;i<l;i++)
	{
		N=(N*10)+(ch[i]-48);
	}
	return N;
}

int main(int argc,char *argv[])
{
	if(argc!=2) { return 1; }
	int N,i,id;
	//N=getNum(argv[1]);
        N=2;
	printf(1,"N is :%d.\n",N);
	printf(1,"pid of the Process is : %d.\n",getpid());
	for(i=1;i<N;i++)
	{
		id=fork();
		if(id>0)
		{
			printf(1, "Parent %d creating child  %d\n", getpid(), id );
			//printf("pid of the pProcess is : %d.\n",getpid());
			//wait();
			sleep(1);
			//break;
		}
		else
		if(id==0)
		{
			//printf(1,"pid of the Process is : %d.\n",getpid());
			//if(i==N-1) { sleep(10000); }
			printf(1,"Child Process : %d \n",getpid());
			for(i=1;i<=1000000000;i++)
			{

			}
			break;
		}
	}
	//return 0;
	exit();
}*/
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"

int
main(int argc, char *argv[])
{
  if(argc < 2){ 
    printf(2," smaller number of arguments than specified , error !\n ");
    exit();
  }

  if(argc > 2){
    printf(2," greater number of arguments than specified , error !\n ");
    exit();
  }

  int i=0;
  int num=atoi(argv[1]);

  num--;

  int pp=fork();

  for(i=1;i<num;i++){
     if(pp == 0 ){
        pp=fork();
     }
  }

  if(pp != 0){
     wait();
     exit();
  }

  sleep(1000);
  exit();
}
