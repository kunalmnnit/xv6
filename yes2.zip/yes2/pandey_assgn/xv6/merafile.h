struct process_info
{
   uint sz;
   int pid;
   int ppid;
   char name[16];   
   char state[16];
};
