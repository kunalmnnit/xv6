#include <stdio.h>

#include "head.h"


int main()
{
  //subfile();
  printf("hello world\n");
  return 0;
}
