#include <bits/stdc++.h>
using namespace std;
#define SIZE 10

int pageFaultsLRU(int pages[], int n, int capacity) 
{ 
     
    unordered_set<int> s; 
  
    unordered_map<int, int> indexes; 
  
    int page_faults = 0; 
    for (int i=0; i<n; i++) 
    { 
        
        if (s.size() < capacity) 
        { 
            if (s.find(pages[i])==s.end()) 
            { 
                s.insert(pages[i]); 
  
                page_faults++; 
            } 
  
            indexes[pages[i]] = i; 
        } 
  
        else
        { 
            if (s.find(pages[i]) == s.end()) 
            { 
                int lru = INT_MAX, val; 
                for (auto it=s.begin(); it!=s.end(); it++) 
                { 
                    if (indexes[*it] < lru) 
                    { 
                    	val = *it;
                        lru = indexes[val];     
                    }
                } 
  
                s.erase(val); 
  
                s.insert(pages[i]); 
  
                page_faults++; 
            } 
  
            indexes[pages[i]] = i; 
        } 
    } 
  
    return page_faults; 
} 












int pageFaultsFIFO(int pages[], int n, int capacity) 
{ 
    unordered_set<int> s; 
  
    queue<int> indexes; 
  
    int page_faults = 0; 
    for (int i=0; i<n; i++) 
    { 
        if (s.size() < capacity) 
        { 
            if (s.find(pages[i])==s.end()) 
            { 
                s.insert(pages[i]); 
  
                
                page_faults++; 
  
                
                indexes.push(pages[i]); 
            } 
        } 
  
        else
        { 
            
            if (s.find(pages[i]) == s.end()) 
            { 
                int val = indexes.front(); 
  
                indexes.pop(); 
  		        s.erase(val); 
  		        s.insert(pages[i]); 
  		        indexes.push(pages[i]); 
  		        page_faults++; 
            } 
        } 
    } 
  
    return page_faults; 
} 


int main()
{
	//Random String Generation
	int pageReferenceString[SIZE];
	int i,j;
	srand((unsigned int)time(NULL));

	for(i=0;i<SIZE;i++)
	{
		int r=rand()%20;
		pageReferenceString[i]=r;
	}

	for(int i=1;i<=7;i++)
	{
		int faults=pageFaults(pageReferenceString,SIZE,i);

		printf("For %d pageframes there will be %d pagefaults in above generated ref string\n",i,faults);
	}

}




